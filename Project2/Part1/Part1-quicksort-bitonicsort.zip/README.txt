To compile all files run make.


Quicksort:
- quicksortSequential:
	Args: size of input array
	Output: Elapsed Time
- quicksortPthreads:
	Args: size of input array
	Output: Elapsed Time


BitonicSort:
- bitonicsortSequential:
	Args: size of input array
	Output: Elapsed Time

- pth_bitonic:
	Args: 1. number of threads (must be a power of two)
		  2. size of input array (must be divisible by number of threads)
	Output: Elapsed time